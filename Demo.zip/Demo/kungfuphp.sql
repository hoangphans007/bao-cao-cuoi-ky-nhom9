-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2018 at 07:49 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kungfuphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin`, `pass`) VALUES
(1, 'admin', 'a'),
(2, 'admin1', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `binhluan`
--

CREATE TABLE IF NOT EXISTS `binhluan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(30) NOT NULL,
  `noidung` text CHARACTER SET utf8 NOT NULL,
  `idpost` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `binhluan`
--

INSERT INTO `binhluan` (`id`, `user`, `noidung`, `idpost`, `iduser`) VALUES
(16, 'thachbn', 'ádsd', 47, 0),
(17, 'thachbn', 'sdsds', 47, 0),
(18, 'thachbn', 'sml', 47, 0),
(19, 'thachbn', 'Bao nhiêu thế anh trai.. ', 49, 0),
(20, 'lambro', '100 củ e ơi', 49, 0),
(21, 'thachbn', 'dep', 51, 0),
(22, 'thachbn', 'rất đẹp', 51, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(20) NOT NULL,
  `img` text CHARACTER SET utf8 NOT NULL,
  `nameproduct` varchar(255) CHARACTER SET utf8 NOT NULL,
  `cart` int(11) NOT NULL,
  `soluong` int(100) NOT NULL COMMENT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tille` text CHARACTER SET utf8 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `hinh` text NOT NULL,
  `chedo` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `tille`, `content`, `hinh`, `chedo`) VALUES
(3, 'sdsd', 'dwdqdwq', '', 0),
(4, 'dealine', 'dealine ', '45288684_1143850052434059_337885163075665920_o.jpg', 0),
(5, 'a', 'a', '45288684_1143850052434059_337885163075665920_o.jpg', 0),
(6, 'a', 'a', 'c329bc4ae2f202ac5be3.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `donhang`
--

CREATE TABLE IF NOT EXISTS `donhang` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `tennguoinhan` varchar(255) CHARACTER SET utf8 NOT NULL,
  `diachi` text CHARACTER SET utf8 NOT NULL,
  `thanhpho` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` int(20) NOT NULL,
  `mathang` varchar(255) CHARACTER SET utf8 NOT NULL,
  `tong` int(11) NOT NULL,
  `1` varchar(255) CHARACTER SET utf8 NOT NULL,
  `2` varchar(255) CHARACTER SET utf8 NOT NULL,
  `3` varchar(255) CHARACTER SET utf8 NOT NULL,
  `4` varchar(255) CHARACTER SET utf8 NOT NULL,
  `5` varchar(255) CHARACTER SET utf8 NOT NULL,
  `6` varchar(255) NOT NULL,
  `7` varchar(255) NOT NULL,
  `8` varchar(255) NOT NULL,
  `10` varchar(255) NOT NULL,
  `9` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `1` (`1`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `donhang`
--

INSERT INTO `donhang` (`id`, `tennguoinhan`, `diachi`, `thanhpho`, `email`, `phone`, `mathang`, `tong`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `10`, `9`) VALUES
(3, 'thach', '', 'TP.Hồ Chí Minh', 'a@gmail.com', 1674742023, '', 0, '', '', '', '', '', '0', '0', '0', '0', '0'),
(5, 'thach', '', 'Cần Thơ', 'ngocthach0328@gmail.com', 1674742023, '', 0, '', '', '', '', '', '0', '0', '0', '0', '0'),
(6, 'thach', '', 'Đà Nẵng', 'thac11@gmail.com', 987654, '', 0, '', '', '', '', '', '0', '0', '0', '0', '0'),
(7, 'thach', '', 'TP.Hồ Chí Minh', 'thach3455@gmail.com', 987654, '', 0, '', '', '', '', '', '0', '0', '0', '0', '0'),
(8, 'thach', '', 'TP.Hồ Chí Minh', 'thach2343@gmail.com', 987654, '', 0, '', '', '', '', '', '0', '0', '0', '0', '0'),
(9, 'thach', '', 'TP.Hồ Chí Minh', 'thach234333@gmail.com', 987654, '', 0, '', '', '', '', '', '0', '0', '0', '0', '0'),
(17, 'user', 'hòaan', 'AX', 'user@gmail.com', 987654, 'nameproduct', 0, '', '', '', '', '', '', '', '', '', ''),
(18, 'd', 'ds', 'TP.Hồ Chí Minh', 'thach@gmail.com', 1674264579, '', 0, '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` text CHARACTER SET utf8 NOT NULL,
  `user` varchar(30) NOT NULL,
  `nameproduct` varchar(255) CHARACTER SET utf8 NOT NULL,
  `newcart` int(11) NOT NULL,
  `oldcart` int(20) NOT NULL,
  `soluong` int(100) DEFAULT '1',
  `info` text CHARACTER SET utf8 NOT NULL,
  `brand` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `phone`, `code`) VALUES
(3, 'phung', 'phung', 'Nguyễn Văn Phùng', 'z@gmail.com', '01642915198', ''),
(4, 'hát', 'thach', 'nguyen van hát', 'az@gmail.com', '0164', ''),
(5, 'co tien', 'thach', 'tien', 'cotien@gmail.com', '01674264579', 'XXXXX'),
(7, 'phung oc', 'thach', 'oc phung oc', 'oc@gmail.com', '01675752023 oc', ''),
(8, 'e', 'thach', 'e', 'e@gmail.com', '01010', ''),
(9, 'a', 'thach', 'thach', 'thach@gmail.com', '098765432', ''),
(11, 'afvdff', 'fdff', 'Mỹdd Đình [HN]', 'udsdsser@gmail.com', '01674264579', ''),
(12, 'thachg', 'ẻggr', 'rẻ', 'phunsg@gmail.com', '01674264579', ''),
(13, 'ư', 'ewư', 'Hoàsng Diệu [ĐN]', 'thxxxxach@gmail.com', '01675752023', ''),
(14, 'adminds', 'dffdsf', 'Hoxx àng Diệu [ĐN]', 'usezzzzzr@gmail.com', '01677264579', ''),
(15, 'thachbn', 'a112233', 'Bùi Ngọc Thạch', 'ngocthach0328@gmail.com', '0987654', ''),
(16, 'lambro', 'lambede', 'Anh Lâm Tym TO', 'lamdt@gmail.com', '1900009876', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
