<?php session_start();

if(isset($_SESSION['sumcart'])){
            //$_SESSION['sumcart']=$_SESSION['sumcart'] + $_SESSION['cart'];
            $_SESSION['sumcart']=0;

        }

if(isset($_SESSION['tong'])){
            //$_SESSION['tong']=$_SESSION['tong'] + $_SESSION['soluong'];
             $_SESSION['tong']=0;
        }
        require_once('lib/connection.php');
        $sql="select id from cart";
        $kt=mysqli_query($conn,$sql);
        if(mysqli_num_rows($kt)  > 0){
         while($row=$kt->fetch_array(MYSQLI_ASSOC)){
         		$id=$row['id'];
         		$sql1="delete from cart where id=$id";
         		mysqli_query($conn,$sql1);

         	}
     	}


header('Location: trangchu.php')

?>