<?php session_start();
$idd=$_GET['id'];
$_SESSION['id']=$idd;
?>
<html lang="en">
  <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Trang hãng xe</title>
    
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   
    <div class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="user-menu">
                        <ul>
                            <?php
                                if(isset($_SESSION["username"]) && $_SESSION['username']){
                                    echo"<li><span style='color: red'>Xin Chào :</span></li>"; echo "<a href='user.php'><b><i class='fa fa-user'> </i><font size='4'> ".$_SESSION['username']."</font></b></a>"; echo" | "; echo"<a href='logout.php'><b><i class='fa fa-sign-out'></i> Đăng xuất </b></i></a>";
                                }else{
                            ?>
                            <li><a href="login.php"><i class="fa fa-sign-in"></i>Đăng nhập</a></li>
                            <li>|</li>
                            <li><a href="register.php"><i class="fa fa-user-plus"></i>Đăng ký</a></li>
                            <?php } ?>
                            
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div> <!-- End header area -->
        
    
        
        <div class="mainmenu-area">
            <div class="container">
                <div class="row">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">                        
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div> 
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li ><a href="honda.php" ><i class="fa fa-home"> </i> TRANG CHỦ</a></li>
                        
                        <li ><a href="lienhe.php"><i class="fa fa-book"></i> THÊM BÀI VIẾT</a></li>
                        <li class="active"><a href="lienhe.php"><i class="fa fa-book"></i>CHI TIẾT BÀI VIẾT</a></li>
                        
                        
                        
            
                    </ul>
                </div>  
            </div>
        </div>
    </div>
     


    <hr>
    <div class="innertube">
    <table align="center">
    


        
        <form action="comment.php" method="post">

        <tr>
                
                <?php
                            $idd=$_GET['id'];

                            $brand="Công khai";
                            require_once('lib/connection.php');
                            $sql="select * from product where id='$idd'";
                            $kt=mysqli_query($conn,$sql);
                            if(mysqli_num_rows($kt)  > 0){
                                while($row=$kt->fetch_array(MYSQLI_ASSOC)){
                                    $id=$row['id'];
                                    $img=$row['img'];
                                    $nameproduct=$row['nameproduct'];
                                    $user=$row['user'];
                                    $info=$row['info'];
                                    
                                
                                
                            ?>
                            
                            

                 

                    <td>

                    <div class="single-shop-product">
                        <div ><?php echo"<b?>Được đăng bởi:<a href='user.php?id=$id';?> $user</a></b>";?></div>
                        <div><?php echo"<b?>Tiêu đề: $nameproduct</b>";?></div>
                        <div class="product-upper">
                            <img src="img/<?php echo"$img";?>" alt="" style="width: 300px">
                        </div>
                        <div><?php echo"<b?>Bài viết: $info</b>";?></div>
                        

                                             
                    </div>
                    <hr>
                    <div><textarea name="info" cols="100"></textarea></div>
                    <div colspan="2" align="center"><input type="submit" name="btn_submit" value="Bình luận"></div>
                </td>
            </tr>
            
                <?php  
                    
                                
                    }
                }
                  ?>
              </form>
              </table>

            </div>
            <hr>
    <div class="innertube">
    <table align="center">
          <?php $i=0; ?>  
        <tr>
                
                <?php
                    
                            $idd=$_GET['id'];
                            require_once('lib/connection.php');
                            $sql="select * from binhluan where idpost='$idd'";
                            $kt=mysqli_query($conn,$sql);
                            if(mysqli_num_rows($kt)  > 0){
                                while($row=$kt->fetch_array(MYSQLI_ASSOC)){
                                    $id=$row['id'];
                                    $user=$row['user'];
                                    $noidung=$row['noidung'];
                                    
                                    
                                    
                                
                                if($i==1){
                                        echo"</tr>";
                                        $i=0;
                                    }
                            ?>
                            
                            

                 

                    <td>

                    <div class="single-shop-product">
                        <div ><?php echo"<b?>Ý kiến:<a href='user.php';?> $user:</a>$noidung</b>";?></div>
                        
                        
                        
                         
                         
                        
                                         
                    </div>
                </td>
                <?php  
                    $i++;
                                
                    }
                }
                  ?>
              </table>
            </div>
            
                
            



    
   
    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="js/main.js"></script>
  </body>
</html>
