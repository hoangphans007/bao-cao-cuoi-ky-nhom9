<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


<?php
session_start();
                        
                        if (isset($_POST["update"])){
                            $id=intval($_GET['id']);
                            require_once("include/connection1.php");
                            $hinh=$_FILES["hinh"]["name"];
                            $name = $_POST["name"];
                            $newcart = $_POST["newcart"];
                            $oldcart = $_POST["oldcart"];
                            $info=$_POST["info"];
                            $hangxe=$_POST['hangxe'];
                            if($name==""||$newcart==""||$oldcart==""){
                                echo '<script language="javascript">alert("không được để trống"); window.location="quanlysanpham.php?id='.$_GET['id'].'";</script>';
                            }else{
                            
                                    if($_FILES["hinh"]["name"] != NULL)
                                        {
                                            if($_FILES["hinh"]["type"] == "image/gif"||$_FILES["hinh"]["type"] == "image/png"||$_FILES["hinh"]["type"] == "image/jpeg" || $_FILES["hinh"]["type"] == "image/jpg" || $_FILES["hinh"]["type"] == "image/pjeg")
                                            {
                                                move_uploaded_file($_FILES["hinh"]["tmp_name"],"../img/".$_FILES["hinh"]["name"]);
                            
                            
                                                }
                                    
                                        $sql="UPDATE product SET img='$hinh', nameproduct='$name', newcart='$newcart',oldcart='$oldcart',info='$info',brand='$hangxe' WHERE id=$id";
                                        mysqli_query($conn,$sql);
                                        echo '<script language="javascript">alert("Thay đổi thành công"); window.location="quanlysanpham.php";</script>';
                                    }else{
                                        $sql="UPDATE product SET nameproduct='$name', newcart='$newcart',oldcart='$oldcart',info='$info',brand='$hangxe' WHERE id=$id";
                                        mysqli_query($conn,$sql);
                                        echo '<script language="javascript">alert("Thay đổi thành công"); window.location="quanlysanpham.php";</script>';
                                    }
                                }
                            }
                            


    ?>