<?php
session_start();
	require_once("include/connection1.php");
 	
	$id = intval($_GET['id']);
	$sql1 = "delete from product where id = $id";
	$query = mysqli_query($conn, $sql1);

	header('Location: quanlysanpham.php');
 
?>