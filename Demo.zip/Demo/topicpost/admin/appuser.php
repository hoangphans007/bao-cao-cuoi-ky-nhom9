

<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">


<?php
                            session_start();
                        require_once("include/connection1.php");
                        if(isset($_POST["themthanhvien"])){
                        	
                            $username = $_POST["username"];
                            $password = $_POST["pass"];
                            $name = $_POST["name"];
                            $email = $_POST["email"];
                            $phone=$_POST["phone"];
                            $pq=$_POST["phanquyen"];
                            if($username == "" || $password == "" || $name == "" || $email == "" ||$phone==""){
                                        echo '<script language="javascript">alert("Không được để trống!"); window.location="themthanhvien.php";</script>';
                            }else
                                    if($pq=="Chọn Phân Quyền"){
                                        echo '<script language="javascript">alert("Chọn Phân Quyền!"); window.location="themthanhvien.php";</script>';
                                    }else{
                                        if($pq=="admin"){
                                            $sql="select * from admin where admin='$username'";
                                            $kt=mysqli_query($conn, $sql);


                                            if(mysqli_num_rows($kt)  > 0){
                                                echo '<script language="javascript">alert("Tài khoản đã tồn tại!"); window.location="themthanhvien.php";</script>';
                                            }else{

                                                $sql="INSERT INTO admin(admin,pass) VALUES ('$username','$password')";
                                                mysqli_query($conn,$sql);
                                                echo '<script language="javascript">alert("Thêm Thành viên quản trị thành công!"); window.location="quanly.php";</script>';
                                            }  

                                        }else{
                                            if($pq=="users"){
                                                $sql="select * from admin where admin='$username'";
                                                $kt=mysqli_query($conn, $sql);


                                                if(mysqli_num_rows($kt)  > 0){
                                                echo '<script language="javascript">alert("Tài khoản đã tồn tại!"); window.location="themthanhvien.php";</script>';

                                                }else{
                                                $sql="select * from users where username='$username'";
                                                $kt=mysqli_query($conn, $sql);

                                                if(mysqli_num_rows($kt)  > 0){
                                                    echo '<script language="javascript">alert("Tài khoản đã tồn tại!"); window.location="themthanhvien.php";</script>';
                                                }else{
                                                    $sql="select * from users where email='$email'";
                                                    $kt=mysqli_query($conn, $sql);
                                                    if(mysqli_num_rows($kt)>0){
                                                        echo '<script language="javascript">alert("Email đã đăng ký!"); window.location="themthanhvien.php";</script>';
                                                
                                                    }else{
                                                        
                                                        $sql = "INSERT INTO users(
                                                            username,
                                                            password,
                                                            name,
                                                            email,
                                                            phone
                                                            ) VALUES (
                                                            '$username',
                                                            '$password',
                                                            '$name',
                                                            '$email',
                                                            '$phone'
                                                            )";
                                                        
                                                        mysqli_query($conn,$sql);

                                                       	echo '<script language="javascript">alert("Thêm thành viên thành công!"); window.location="quanly.php";</script>';
                                                        

                                        		      } 
                                                  }
                                                }
                                            }  
                                        }
                                    }
                                }

                        
                
    
                          
                            
             ?>
