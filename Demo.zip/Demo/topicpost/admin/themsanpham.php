<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>
    <title>Trang Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <style type="text/css" media="screen">
      .khung
    {
      margin:  30px auto;
      padding: 10px;
      border-radius: 5px;
      color: #3c763d;
      background: #dff0d8;
      border: 1px solid #3c763d;
      width: 50%;
      text-align: center;
    }

        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
    
</style>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
</head>
  <body>
   
    
    
        
    
	 <style type="text/css" media="screen">
      .khung
    {
      margin:  30px auto;
      padding: 10px;
      border-radius: 5px;
      color: #3c763d;
      background: #dff0d8;
      border: 1px solid #3c763d;
      width: 50%;
      text-align: center;
    }

        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
    
</style>

	<!--Xuat thong bao-->


	<h1 align="center"><a href="quanlysanpham.php">Welcome admin</a></h1>
    <p><a href="../trangchu.php" title="" class="btn btn-danger">Trở về Trang chủ</a></p> <p><a class="btn btn-danger" href="dangxuat.php"><i class="fa fa-user"></i>Đăng xuất</a></p>
    <div class="row">
        <div class="col-md-2">
            <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Quản Lý sản phẩm
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
              <li><a href="honda.php">Honda</a></li>
              <li><a href="yamaha.php">Yamaha</a></li>
              <li><a href="piaggio.php">Piaggio</a></li>
              <li><a href="quanlysanpham.php" >Tất cả</a></li>
            </ul>
          </div>
      </div>
        <div class="col-md-2">
            <div class="dropdown">
            <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Quản Lý Thành viên
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="quanly.php">Xem thành viên</a></li>
              <li><a href="themthanhvien.php">Thêm thành viên</a></li>
              <li><a href="#">Theo dỗi phản hồi</a></li>
              <li><a href="#">Theo dỗi đơn hàng</a></li>
              
            </ul>
          </div>
      </div>
            <p><a class="btn btn-success" href="themsanpham.php"><i class="fa fa-user"></i>Thêm sản phẩm</a></p>
            
    </div>
            			<form action="appcart.php" method="post"  enctype='multipart/form-data'>
                        
                        <fieldset class="khung">
                            <legend align="center" class="khung"><h3 style="color: red">Thêm sản phẩm mới</h3></legend>
                        
                        <table width="400" height="200" align="center">
                            <tr>
                                <td>Hình ảnh :</td>
                                <td><input type="file" name="hinh" ></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Tên sản phẩm :</td>
                                <td><input type="text" name="name" ></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Giá mới :</td>
                                <td><input type="number" name="newcart" ></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Giá cũ :</td>
                                <td><input type="number" name="oldcart" ></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Mô tả :</td>
                                <td><textarea name="info" cols="30" rows="10"></textarea></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                            <td> Hãng xe :</td>
                            <td><select name="hangxe">
                            <option>Chọn Hãng xe</option>
                            <option>Honda</option>
                            <option>Yamaha</option>
                            <option>Piaggio</option>
                            
                                                          
                                                            
                            </select></td>


                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td colspan="2" align="center"><input type="submit" name="submit" value="Thêm sản phẩm"></td>
                            </tr>

                        </table>
                    </fieldset>
                </form>
               

                </form>
                    <hr>
                 <form action="quanlysanpham.php" method="post">
                    <table width="100%" border="1">
						<tr>
							<th>STT</th>
							<th>Hình ảnh</th>
							<th>Tên sản phẩm</th>
							<th>Giá mới</th>
							<th>Giá cũ</th>
							<th>Mô tả</th>
							<td></td>
							<td></td>
						</tr>
						<tr>
                
                		<?php
                
                   			$i=0;
                            require_once('include/connection1.php');
                            $sql="select id,img,nameproduct,newcart,oldcart,info from product";
                            $kt=mysqli_query($conn,$sql);
                            if(mysqli_num_rows($kt)  > 0){
                            	$stt=1;
                                while($row=$kt->fetch_array(MYSQLI_ASSOC)){
                                    $id=$row['id'];
                                    $img=$row['img'];
                                    $nameproduct=$row['nameproduct'];
                                    $newcart=$row['newcart'];
                                    $oldcart=$row['oldcart'];
                                    $info=$row['info'];
                                
                                if($i==8){
                                        echo"</tr>";
                                        $i=0;
                                    }
                                echo"<td>$stt</td>";
                                $i++;$stt++;
                                echo"<td><img src='../img/$img' style='width:200px'></td>";
                                $i++;
                                echo"<td>$nameproduct</td>";
                                $i++;	
                                echo"<td>$newcart</td>";
                                $i++;
                                echo"<td>$oldcart</td>";
                                $i++;
                                echo"<td>$info<S/td>";
                                $i++;
                                echo"<td><a href='quanlysanpham.php?id=$id' class='btn btn-primary'>Sữa</a></td>";
                                $i++;
                                echo"<td><a href='xoasanpham.php?id=$id' class='btn btn-danger'>Xóa</a></td>";
                                $i++;
                            }

                        }
                            ?>
                            
                            

                 


                    </table>
                </form>
                <br>
                <br>
</body>
</html>