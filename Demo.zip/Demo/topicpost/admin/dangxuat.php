<?php session_start(); 
 
	session_destroy();
    header("Location: ../trangchu.php") ;// xóa session login


?>