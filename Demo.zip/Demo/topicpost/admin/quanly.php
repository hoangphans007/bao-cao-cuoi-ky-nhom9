<?php session_start();
    

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Trang Admin</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	 <style type="text/css" media="screen">
      .khung
    {
      margin:  30px auto;
      padding: 10px;
      border-radius: 5px;
      color: #3c763d;
      background: #dff0d8;
      border: 1px solid #3c763d;
      width: 50%;
      text-align: center;
    }

        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
    
</style>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
</head>
<body >
	<!--Xuat thong bao-->



    <h1 align="center"><a href="quanly.php">Welcome admin</a></h1>
    <p><a href="../trangchu.php" title="" class="btn btn-danger">Trở về Trang chủ</a></p> <p><a class="btn btn-danger" href="dangxuat.php"><i class="fa fa-user"></i>Đăng xuất</a></p>
    <div class="row">
        <div class="col-md-2">
            <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Quản Lý sản phẩm
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
              <li><a href="honda.php">Honda</a></li>
              <li><a href="yamaha.php">Yamaha</a></li>
              <li><a href="piaggio.php">Piaggio</a></li>
              <li><a href="quanlysanpham.php">Tất cả</a></li>
            </ul>
          </div>
      </div>
      <div class="col-md-2">
            <div class="dropdown">
            <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Quản Lý Thành viên
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="quanly.php" style="color: red">Xem thành viên</a></li>
              <li><a href="themthanhvien.php">Thêm thành viên</a></li>
              <li><a href="theodoiphanhoi.php">Theo dỗi phản hồi</a></li>
              
              
            </ul>
          </div>
      </div>
            
    </div>
				<?php
						if(isset($_GET['id'])){
								$i=$_GET['id'];
                            require_once('include/connection1.php');
                            $sql="select * from users where id='$i' ";
                            $kt=mysqli_query($conn,$sql);
                            if(mysqli_num_rows($kt)  > 0){
                            
                                while($row=$kt->fetch_array(MYSQLI_ASSOC)){
                                    $id=$row['id'];
                                    $username=$row['username'];
                                    $password=$row['password'];
                                    $name=$row['name'];
                                    $email=$row['email'];
                                    $phone=$row['phone'];

									}
							?>
			
	<form action="capnhatuser.php?id=<?php echo"$id";?>" method="post"">
						
                        <fieldset class="khung">
                            <legend align="center" class="khung">Thay đổi thông tin thành viên</legend>
                        
                        <table width="400" height="200" align="center">
                            <tr>
                                <td>Tài khoản :</td>
                                <td><input type="text" name="username" value="<?php echo"$username";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Mật khẩu :</td>
                                <td><input type="text" name="pass" value="<?php echo"$password";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Họ Tên :</td>
                                <td><input type="text" name="name" value="<?php echo"$name";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Số điện thoại :</td>
                                <td><input type="number" name="phone" value="<?php echo"$phone";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Email :</td>
                                <td><input type="email" name="email" value="<?php echo"$email";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td colspan="2" align="center"><input type="submit" name="update" value="Cập nhập"></td>
                            </tr>

                        </table>
                    </fieldset>
                </form>
                    <?php
                	}
                    }else{}
                	?>
                </form>
                    <hr>
                 <form action="quanly.php?" method="post" class="khung" style="width: 100%">
                    <fieldset>
                        <legend class="khung" align="center" style="color: red;background:pink">Quản lý thành viên</legend>
                    
                    <table width="100%" border="1">
						<tr>
							<th>STT</th>
							<th>Tài khoản</th>
							<th>Mật khẩu</th>
							<th>Họ & Tên</th>
							<th>Số điện thoại</th>
							<th>Email</th>
							<td></td>
							<td></td>
						</tr>
						<tr>
                
                		<?php
                
                   			$i=0;
                            require_once('include/connection1.php');
                            $sql="select id,username,password,name,email,phone from users";
                            $kt=mysqli_query($conn,$sql);
                            if(mysqli_num_rows($kt)  > 0){
                            	$stt=1;
                                while($row=$kt->fetch_array(MYSQLI_ASSOC)){
                                    $id=$row['id'];
                                    $username=$row['username'];
                                    $password=$row['password'];
                                    $name=$row['name'];
                                    $email=$row['email'];
                                    $phone=$row['phone'];
                                
                                if($i==8){
                                        echo"</tr>";
                                        $i=0;
                                    }
                                echo"<td>$stt</td>";
                                $i++;$stt++;
                                echo"<td>$username</td>";
                                $i++;
                                echo"<td>$password</td>";
                                $i++;	
                                echo"<td>$name</td>";
                                $i++;
                                echo"<td>$phone</td>";
                                $i++;
                                echo"<td>$email<S/td>";
                                $i++;
                                echo"<td><a href='quanly.php?id=$id' class='btn btn-primary'>Sữa</a></td>";
                                $i++;
                                echo"<td><a href='xoauser.php?id=$id' class='btn btn-danger'>Xóa</a></td>";
                                $i++;
                            }

                        }
                            ?>
                            
                            

                 


                    </table>
                </fieldset>
                </form>
                <br>
                <br>
</body>
</html>