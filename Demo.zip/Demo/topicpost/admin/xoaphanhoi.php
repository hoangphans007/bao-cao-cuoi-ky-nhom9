<?php
session_start();
require_once("include/connection1.php");
 
	$id = intval($_GET['id']);
	$sql="delete  from comment where id=$id";
	$kt=mysqli_query($conn,$sql);
	header('Location: theodoiphanhoi.php')
?>