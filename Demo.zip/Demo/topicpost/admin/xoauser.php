<?php
session_start();
require_once("include/connection1.php");
 
	$id = intval($_GET['id']);
	$sql="delete  from users where id=$id";
	$kt=mysqli_query($conn,$sql);
	header('Location: quanly.php')
?>