                      <?php
                      session_start();
                            if(isset($_GET['id'])){
                              $id=intval($_GET['id']);
                              if(isset($_POST['update'])){
                              require_once('include/connection1.php');
                              
                              $traloi=$_POST['traloi']; 
                                    
                            
                             
                          
                                    $sql="UPDATE comment SET traloi='$traloi' WHERE id=$id";
                                    mysqli_query($conn,$sql);
                                        
                                   echo '<script language="javascript">alert("Trả lời thành công!"); window.location="theodoiphanhoi.php?id='.$_GET['id'].'"</script>';
                                            
                                        
                              }

                            }
                            }
                       ?>
                       <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">