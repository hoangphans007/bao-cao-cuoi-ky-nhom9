

<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">


<?php
session_start();
                        
                        if (isset($_POST["submit"])){
                        	require_once("include/connection1.php");
                            $hinh=$_FILES["hinh"]["name"];
                            $name = $_POST["name"];
                            $newcart = $_POST["newcart"];
                            $oldcart = $_POST["oldcart"];
                            $info=$_POST["info"];
                            $hangxe=$_POST['hangxe'];
                            if($hinh==""||$name==""||$newcart==""||$oldcart==""){
                                echo '<script language="javascript">alert("Thêm đầy đủ thông tin"); window.location="themsanpham.php";</script>';
                            }else{
                                    if($hangxe=="Chọn Hãng xe"){
                                        echo '<script language="javascript">alert("Chưa chọn hãng xe"); window.location="themsanpham.php";</script>';
                                    }else{
                            
                                        if($_FILES["hinh"]["name"] != NULL)
                                        {
                                            if($_FILES["hinh"]["type"] == "image/gif"||$_FILES["hinh"]["type"] == "image/png"||$_FILES["hinh"]["type"] == "image/jpeg" || $_FILES["hinh"]["type"] == "image/jpg" || $_FILES["hinh"]["type"] == "image/pjeg")
                                            {
                                                move_uploaded_file($_FILES["hinh"]["tmp_name"],"../img/".$_FILES["hinh"]["name"]);
                            
                            
                                            }
                                        
                                        $sql="select * from product where nameproduct='$name' ";
                                        $kt=mysqli_query($conn, $sql);

                                        if(mysqli_num_rows($kt)  > 0){
                                            echo '<script language="javascript">alert("Sản phẩm đã có"); window.location="themsanpham.php";</script>';
                                        }else{
                                                    
                                                    $sql = "INSERT INTO product(
                                                        img,
                                                        nameproduct,
                                                        newcart,
                                                        oldcart,
                                                        info,
                                                        brand
                                                        ) VALUES (
                                                        '$hinh',
                                                        '$name',
                                                        '$newcart',
                                                        '$oldcart',
                                                        '$info',
                                                        '$hangxe'
                                                        )";
                                                    
                                                    mysqli_query($conn,$sql);

                                                   	echo '<script language="javascript">alert("Thêm sản phẩm thành công!"); window.location="quanlysanpham.php";</script>';
                                                    

                                    	                                        	
                                            } 
                                            }
                                            } 
                                    
                            }
                                
                            }
    
                          
                            
                    ?>
