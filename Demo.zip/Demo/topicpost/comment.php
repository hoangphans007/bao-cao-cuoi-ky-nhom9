

<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


<?php
session_start();
        require_once("lib/connection.php");

     
        if(isset($_POST['btn_submit'])){
            $info=$_POST['info'];
            $user=$_SESSION["username"];
            $i=$_SESSION["id"];
            
                        
                        
                                    
                                    
                            $sql = "INSERT INTO binhluan(
                                                        user,
                                                        noidung,idpost
                                                        
                                                        ) VALUES (
                                                        '$user',
                                                        '$info','$i'
                                                        
                                                        
                                                        )";
                                                    
                                                    mysqli_query($conn,$sql);
                                                    header('Location:honda.php');

        }

     ?>   
                                                    

                                                    
                                                    

                                                                                    
                                          
                                        
                                            
                                        
                                    
                            
                                
                        
    
                          
                         
                    ?>
