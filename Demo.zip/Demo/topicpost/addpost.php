

<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


<?php
session_start();
                        $user=$_SESSION["username"];
                        if (isset($_POST["submit"])){
                            require_once("lib/connection.php");
                            $hinh=$_FILES["hinh"]["name"];
                            $name = $_POST["name"];
                           
                            $info=$_POST["info"];
                            $hangxe=$_POST['chedo'];
                            
                            if($hinh==""||$name==""){
                                echo '<script language="javascript">alert("Thêm đầy đủ thông tin"); window.location="lienhe.php";</script>';
                            }else{
                                    
                                        
                                    
                            
                                        if($_FILES["hinh"]["name"] != NULL)
                                        {
                                            if($_FILES["hinh"]["type"] == "image/gif"||$_FILES["hinh"]["type"] == "image/png"||$_FILES["hinh"]["type"] == "image/jpeg" || $_FILES["hinh"]["type"] == "image/jpg" || $_FILES["hinh"]["type"] == "image/pjeg")
                                            {
                                                move_uploaded_file($_FILES["hinh"]["tmp_name"],"../img/".$_FILES["hinh"]["name"]);
                            
                            
                                            }
                                        
                                       

                                        
                                        
                                                    
                                                    $sql = "INSERT INTO product(
                                                        img,
                                                        nameproduct,
                                                        user,
                                                        info,
                                                        brand
                                                        ) VALUES (
                                                        '$hinh',
                                                        '$name',
                                                        '$user',
                                                        '$info',
                                                        '$hangxe'
                                                        )";
                                                    
                                                    mysqli_query($conn,$sql);

                                                    
                                                    header('location:honda.php');

                                                                                    
                                            } 
                                            
                                        
                                    
                            }
                                
                            }
    
                          
                            
                    ?>
