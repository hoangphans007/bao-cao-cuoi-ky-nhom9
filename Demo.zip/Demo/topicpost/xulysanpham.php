<?php
	session_start();
		$idd=intval($_GET['id']);
 		require_once('lib/connection.php');
        $sql="select * from product where id='$idd'";
        $kt=mysqli_query($conn,$sql);
        if(mysqli_num_rows($kt)  > 0){
        while($row=$kt->fetch_array(MYSQLI_ASSOC)){                  
        
	        $_SESSION['cart']=$row['newcart'];
	        $_SESSION['soluong']=1;
                                
        }
        if(isset($_SESSION['cart'])){
            $_SESSION['sumcart']=$_SESSION['sumcart'] + $_SESSION['cart'];
            //unset($_SESSION['sumcart']);
        }

		if(isset($_SESSION['soluong'])){
            $_SESSION['tong']=$_SESSION['tong'] + $_SESSION['soluong'];
            
        }	
	

	
	header('Location: trangchu.php');
	}

?>