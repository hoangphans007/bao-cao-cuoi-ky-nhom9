
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
    session_start();
        $idd=intval($_GET['id']);
        require_once('lib/connection.php');
        $sql="select * from product where id='$idd'";
        $kt=mysqli_query($conn,$sql);
        if(mysqli_num_rows($kt)  > 0){
        while($row=$kt->fetch_array(MYSQLI_ASSOC)){                  
            $_SESSION['newcart']=$row['newcart'];
            $_SESSION['sumcart']=$_SESSION['sumcart'] + $row['newcart'];
            //unset($_SESSION['sumcart']);
            $_SESSION['tong']=$_SESSION['tong'] + 1;
            
        }
    }
    



?>

<?php
        $idd=intval($_GET['id']);
        require_once('lib/connection.php');
        $sql="select * from product where id='$idd'";
        $kt=mysqli_query($conn,$sql);
        while($row=$kt->fetch_array(MYSQLI_ASSOC)){
            $id=$row['id']; 
            $img=$row['img'];
            $nameproduct=$row['nameproduct'];
            $cart=$row['newcart'];
            $soluong=$row['soluong'];
            }

        $sql="select * from cart where id='$id'";
        $kt=mysqli_query($conn,$sql);
        if(mysqli_num_rows($kt)>0){
            while($row=$kt->fetch_array(MYSQLI_ASSOC)){
                $soluong=$row['soluong']+1;
                $cart=$row['cart'] + $_SESSION['newcart'];
                $sql="UPDATE cart SET  cart='$cart',soluong='$soluong' where id=$id";
                mysqli_query($conn,$sql);
                echo '<script language="javascript">alert("Mua hàng thành công!"); window.location="giohang.php";</script>';
            }
        }else{
        $sql1="INSERT INTO cart(id,img,nameproduct,cart,soluong) VALUES('$id','$img','$nameproduct','$cart','$soluong')";
        mysqli_query($conn,$sql1);
        echo '<script language="javascript">alert("Mua hàng thành công!"); window.location="giohang.php";</script>';
        }
    
?>
