<?php session_start();
 ?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Trang đăng nhập</title>
    
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <style type="text/css" media="screen">
      .khung
    {
      margin:  30px auto;
      padding: 10px;
      border-radius: 5px;
      color: #3c763d;
      background: #dff0d8;
      border: 1px solid #3c763d;
      width: 50%;
      text-align: center;
    }
  </style>
  <body>
    
   
    <div class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="user-menu">
                        <ul>
                            <li><a href="login.php" style="color: black"><i class="fa fa-sign-in"></i>Đăng nhập</a></li>
                            <li>|</li>
                            <li><a href="register.php"><i class="fa fa-user-plus"></i>Đăng ký</a></li>
                            <?php
                                if(isset($_SESSION["username"]) && $_SESSION['username']){
                                    echo"<li><span style='color: red'>Xin Chào :</span></li>"; echo "<a href='user.php'><b><i class='fa fa-user'></i>".$_SESSION['username']."</b></a>"; echo" | "; echo"<a href='logout.php'><b> logout </b></i></a>";
                                }
                            ?>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div> <!-- End header area -->
        
    <!--<div class="site-branding-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="logo">
                            <a href="trangchu.php"><img src="img/honda.png" alt="honda">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="shopping-item">
                            <?php 
                            /*if(isset($_SESSION['sumcart'])){
                                echo"<a href='giohang.php'>Giỏ - ".number_format($_SESSION['sumcart'])."đ<span class='cart-amunt'></span> <i class='fa fa-shopping-cart'></i> <span class='product-count'>".$_SESSION['tong']."</span></a>";
                            }else{
                                echo"<a href='delete.php'>Giỏ - 0đ<span class='cart-amunt'></span> <i class='fa fa-shopping-cart'></i> <span class='product-count'>0</span></a>";
                            }*/
                            ?>
                        </div>
                    </div>
    
                </div>
            </div>
        </div> End site branding area -->

        
        
        
     
    <div class="single-product-area" style="background: #F5F5DC">
        
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   <div class="single-sidebar">

                        <?php
                        
                        require_once("lib/connection.php");
                        
                        if (isset($_POST["btn_submit"])) {
                            // lấy thông tin người dùng
                            $username = $_POST["username"];
                            $password = $_POST["password"];
                            
                            $username = strip_tags($username);
                            $username = addslashes($username);
                            $password = strip_tags($password);
                            $password = addslashes($password);
                            if($username == "" || $password ==""){
                                echo "<p class='khung'>Tài khoản hoặc Mật khẩu bạn không được để trống!</p>";
                            }else{
                                $sql="select *from admin where admin='$username' and pass='$password'";
                                $kt=mysqli_query($conn,$sql);

                                if(mysqli_num_rows($kt)>0){
                                        $_SESSION['username'] = $username;
                                        header('Location: trangchu.php');
                                }else{

                                    $sql = "select * from users where username = '$username' and password = '$password' ";
                                    $query = mysqli_query($conn,$sql);
                                    $num_rows = mysqli_num_rows($query);
                                    if ($num_rows==0) {
                                        echo "<p class='khung'>Tên tài khoản hoặc mật khẩu không đúng !</p>";
                                    }else{
                                        
                                        $_SESSION['username'] = $username;
                                        
                                        header('Location: honda.php');
                                        
       
                                    }
                                }
                            }
                             
                        }
                    ?>
                    
                        <form method="POST" action="login.php" >

                        <fieldset class="khung">
                            <legend class="khung" align="center">Đăng nhập</legend>
                                <table width="400" hieght="200" align="center">

                                    <tr><td colspan="2" align="center"><img src="admin/img/download.png" alt=""
                                        style="width: 50%" style="height:100%" ></td></tr>
                                    <tr><td colspan="2" align="center"> ******  </td></tr>
                                    <tr>
                                        <td>Tài khoản :</td>
                                        <td><input type="text" name="username"></td>
                                    </tr>
                                    <tr>
                                        <td>Mật khẩu :</td>
                                        <td><input type="password" name="password" id="pw" size="30" style="width: 100%"><span toggle="#pw" class="fa fa-fw fa-eye field-icon toggle-password"></span></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="center"> <input name="btn_submit" type="submit" value="Đăng nhập"></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="center"><a class="btn btn-primary" href="register.php">ĐĂNG KÝ tài khoản</a></td>
                                        
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="center"><a class="btn btn-success"  href="" >Quên mật khẩu?</a></td>
                                    </tr>
                                </table>
                      </fieldset>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>
 <!-- <div class="footer-top-area">
       
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="footer-about-us">
                         <img src="img/honda.png" alt="">
                        <div class="footer-social">
                            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-linkedin"></i></a>
                            <a href="#" target="_blank"><i class="fa fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu">
                        <h2 class="footer-wid-title"><b>Khách hàng</b> </h2>
                        <ul>
                            <li><a href="">TÀI KHOẢN</a></li>
                            <li><a href="">ĐẶT HÀNG</a></li>
                            <li><a href="">DANH SÁCH</a></li>
                            <li><a href="">LIÊN HỆ</a></li>
                            <li><a href="">TRANG CHỦ</a></li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu">
                        <h2 class="footer-wid-title"><b>Thanh toán và bảo hành</b></h2>
                        <ul>
                            <li><a href="">Hình thức thanh toán</a></li>
                            <li><a href="">Bảo hành Honda VN</a></li>
                            <li><a href="">Bảo hành Yamaha VN</a></li>
                            <li><a href="">Bảo hành Piaggio VN</a></li>
                            <li><a href="">Bảo hành Suzuki VN</a></li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-newsletter">
                        <h2 class="footer-wid-title"><b>HỖ TRỢ</b></h2>
                        <p>DỊCH VỤ TƯ VẤN VÀ HỖ TRỢ KHÁCH HÀNG</p>
                        <p>Hotline:<span style="color: red">01642915198</span></p>
                        <div class="newsletter-form">
                            <input type="email" placeholder="nhập email">
                            <a href="javascript:alert('Cảm ơn bạn đã góp ý!!!!');"><input type="submit" value="gửi "></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="copyright">
                        <p>&copy; 2015 eElectronics. All Rights Reserved. Coded with <i class="fa fa-heart"></i> by <a href="http://wpexpand.com" target="_blank">WP Expand</a></p>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="footer-card-icon">
                        <i class="fa fa-cc-discover"></i>
                        <i class="fa fa-cc-mastercard"></i>
                        <i class="fa fa-cc-paypal"></i>
                        <i class="fa fa-cc-visa"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>  End footer bottom area -->
   
    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="js/main.js"></script>
</body>
</html>
<script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>
<script>
    $(".toggle-password").click(function() {

        var input =$($(this).attr("toggle"));
        if(input.attr("type")=="password"){
            input.attr("type","text");
        }else{
            input.attr("type","password");
        }
    });
</script>