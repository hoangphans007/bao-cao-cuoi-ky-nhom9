<?php session_start(); ?>





<html lang="en">

  <head>

    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Trang Đăng ký</title>

    

    <!-- Google Fonts -->

    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>

    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>

    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>

    

    <!-- Bootstrap -->

    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

    

    <!-- Font Awesome -->

    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    

    <!-- Custom CSS -->

    <link rel="stylesheet" href="css/owl.carousel.css">

    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="css/responsive.css">



    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->

  </head>

  <style type="text/css" media="screen">

      .khung

    {

      margin:  30px auto;

      padding: 10px;

      border-radius: 5px;

      color: #3c763d;

      background: #dff0d8;

      border: 1px solid #3c763d;

      width: 50%;

      text-align: center;

    }



        input[type=number]::-webkit-inner-spin-button, 

        input[type=number]::-webkit-outer-spin-button { 

      -webkit-appearance: none; 

      margin: 0; 

    }

    

</style>

  <body>

        

    <div class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="user-menu">
                        <ul>
                            <li><a href="login.php" ><i class="fa fa-sign-in"></i>Đăng nhập</a></li>
                            <li>|</li>
                            <li><a href="register.php" style="color: black"><i class="fa fa-user-plus"></i>Đăng ký</a></li>
                            <?php
                                if(isset($_SESSION["username"]) && $_SESSION['username']){
                                    echo"<li><span style='color: red'>Xin Chào :</span></li>"; echo "<a href='user.php'><b><i class='fa fa-user'></i>".$_SESSION['username']."</b></a>"; echo" | "; echo"<a href='logout.php'><b> logout </b></i></a>";
                                }
                            ?>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

        

        

    <div class="single-product-area" style="background: #F5F5DC" >

        

        <div class="container">

            <div class="row">

                <div class="col-md-12">

                   <div class="single-sidebar">

                    <?php

                        require_once("lib/connection.php");

                        if (isset($_POST["btn_submit"])) {

                            $username = $_POST["username"];

                            $password = $_POST["pass"];

                             $name = $_POST["name"];

                            $email = $_POST["email"];

                            $phone=$_POST["phone"];

                            

                            if($username=="admin"){

                                echo"<p class='khung'>Báº¡n khÃ´ng thá»ƒ sá»­ TÃ i khoáº£n nÃ y!</p>";

                            }else{

                                if ($username == "" || $password == "" || $name == "" || $email == "" ||$phone=="") {

                                        

                                       echo "<p class='khung'>Nhập đầy đủ thông tin</p>";

                                }else{

                                         $sql="select * from admin where admin='$username'";

                                        $kt=mysqli_query($conn, $sql);

                                             



                                        if(mysqli_num_rows($kt)  > 0){

                                                echo "<p class='khung'>Tài khoản đã tồn tại</p>";

                                        }else{

                                            $sql="select * from users where username='$username'";

                                            $kt=mysqli_query($conn, $sql);



                                            if(mysqli_num_rows($kt)  > 0){

                                                echo "<p class='khung'>Tài khoản đã tồn tại</p>";

                                            }else

                                            

                                            {

                                            $sql1="select * from users where email='$email'";

                                            $kt1=mysqli_query($conn, $sql1);if(mysqli_num_rows($kt1) > 0){

                                                echo "<p class='khung'>Email đã có. Vui lòng sử dụng Email khác!!!</p>";

                                            

                                                }else{

                                                    

                                                    $sql = "INSERT INTO users(

                                                        username,

                                                        password,

                                                        name,

                                                        email,phone

                                                        ) VALUES (

                                                        '$username',

                                                        '$password',

                                                        '$name',

                                                        '$email','$phone'

                                                        )";

                                                    

                                                    mysqli_query($conn,$sql);



                                                    echo "<p class='khung'>Đăn ký thành công!<a href='login.php'><i>Đăng nhập tại đây!</i></a></p>";

                                                    



                                                } 

                                            }

                                        }

                                        }  

                                    }

                                }

                            

                    ?>

                    

                    <form action="register.php" method="post"">





                        <fieldset class="khung">

                            <legend class="khung" align="center">Đăn ký thành viên</legend>

                        

                        <table width="400" height="200" align="center" >

                            <tr>

                                <td>Tài khoản:</td>

                                <td><input type="text" id="username" name="username" style="width: 100%"></td>

                            </tr>

                            <tr>

                                <td>Mật khẩu :</td>

                                <td><input type="password" id="pass" name="pass" style="width: 100%"></td>

                            </tr>

                            <tr><td colspan="2"><br></td></tr>

                            <tr>

                                <td>Họ và tên :</td>

                                <td><input type="text" id="name" name="name" style="width: 100%"></td>

                            </tr>

                            <tr>

                                <td>Số điện thoại :</td>

                                <td><input type="number" name="phone" style="width: 100%"></td>

                            </tr>

                            <tr><td colspan="2"><br></td></tr>

                            <tr>

                                <td>Email :</td>

                                <td><input type="email" id="email" name="email" style="width: 100%"></td>

                            </tr>

                            <tr>

                                <td colspan="2" align="center"><input type="submit" name="btn_submit" value="Đăng ký"></td>

                            </tr>



                        </table>

                    </fieldset>

                    </form>

                  </div>

              </div>

          </div>

      </div>

  </div>

  

    

    

</body>

</html>

<script

  src="https://code.jquery.com/jquery-3.3.1.js"

  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="

  crossorigin="anonymous"></script>

<script>

    $(".toggle-password").click(function() {



        var input =$($(this).attr("toggle"));

        if(input.attr("type")=="password"){

            input.attr("type","text");

        }else{

            input.attr("type","password");

        }

    });

</script>

