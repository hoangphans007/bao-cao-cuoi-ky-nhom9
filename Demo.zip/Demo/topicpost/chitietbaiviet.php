<?php session_start();
?>
<html lang="en">
  <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Trang hãng xe</title>
    
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   
    <div class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="user-menu">
                        <ul>
                            <?php
                                if(isset($_SESSION["username"]) && $_SESSION['username']){
                                    echo"<li><span style='color: red'>Xin Chào :</span></li>"; echo "<a href='user.php'><b><i class='fa fa-user'> </i><font size='4'> ".$_SESSION['username']."</font></b></a>"; echo" | "; echo"<a href='logout.php'><b><i class='fa fa-sign-out'></i> Đăng xuất </b></i></a>";
                                }else{
                            ?>
                            <li><a href="login.php"><i class="fa fa-sign-in"></i>Đăng nhập</a></li>
                            <li>|</li>
                            <li><a href="register.php"><i class="fa fa-user-plus"></i>Đăng ký</a></li>
                            <?php } ?>
                            
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div> <!-- End header area -->
        
    
        
        <div class="mainmenu-area">
            <div class="container">
                <div class="row">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">                        
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div> 
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li ><a href="honda.php" ><i class="fa fa-home"> </i> TRANG CHỦ</a></li>
                        
                        <li ><a href="lienhe.php"><i class="fa fa-book"></i> THÊM BÀI VIẾT</a></li>
                        <li class="active"><a href="lienhe.php"><i class="fa fa-book"></i>CHI TIẾT BÀI VIẾT</a></li>
                        
                        
                        
            
                    </ul>
                </div>  
            </div>
        </div>
    </div>
     
    <hr>
<?php
						if(isset($_GET['id'])){
								$i=$_GET['id'];
                            require_once('lib/connection.php');
                            $sql="select * from product where id='$i' ";
                            $kt=mysqli_query($conn,$sql);
                            if(mysqli_num_rows($kt)  > 0){
                            
                                while($row=$kt->fetch_array(MYSQLI_ASSOC)){
                                    $id=$row['id'];
                                    $img=$row['img'];
                                    $nameproduct=$row['nameproduct'];
                                    $newcart=$row['newcart'];
                                    $oldcart=$row['oldcart'];
                                    $info=$row['info'];
                                    $brand=$row['brand'];

									}
							?>
			
	<form action="capnhatsanpham.php?id=<?php echo"$id";?>" method="post"" enctype='multipart/form-data' >
						
                        <fieldset class="khung">
                            <legend align="center" class="khung"><h3 style="color: red">Thông tin sản phẩm</h3></legend>
                        
                        <table width="400" height="200" align="center">
                            <tr>
                                <td>Hình cũ:</td>
                                <td><img src="../img/<?php echo"$img";?>" style="width: 200px"></td>
                            </tr>
                            <tr>
                                <td>Hình ảnh mới :</td>
                                <td><input type="file" name="hinh"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Tên sản phẩm :</td>
                                <td><input type="text" name="name" row="10" cols="50" value="<?php echo"$nameproduct";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Giá mới :</td>
                                <td><input type="text" name="newcart" value="<?php echo"$newcart";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td>Giá cũ :</td>
                                <td><input type="text" name="oldcart" value="<?php echo"$oldcart";?>"></td>
                            </tr>
                            <tr><td colspan="2"><br></td></tr>
                            <tr>
                                <td nowrap="nowrap">Mô tả :</td>
                                <td><input type="text" name="info" value="<?php echo"$info";?>"></td> 
                            </tr>
                            <tr>
                            <td> Hãng xe :</td>
                            <td><select name="hangxe" >
                            <option><?php echo"$brand";?></option>
                            <option>Honda</option>
                            <option>Yamaha</option>
                            <option>Piaggio</option>                           
                                                            
                            </select></td>


                            </tr>
                            <tr>
                                <td colspan="2" align="center"><input type="submit" name="update" value="Cập nhập"></td>
                            </tr>

                        </table>
                    </fieldset>
                </form>
                    <?php
                	}
                	}
                    ?>
                </form>
                    <hr>